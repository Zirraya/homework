﻿using System;
using System.Reflection;
using System.IO;
using Librarysincos;
using System.Linq;

namespace _4_6var_Nikitenko_211 // Задание 4 из 4 лабы
{
    internal class Program
    {
        static void Main(string[] args)
        {


           // Динамическое подключение
        // Загружаем сборку
        Assembly loaddill = Assembly.LoadFrom("Librarysincos");

            object o = loaddill.CreateInstance("Librarysincos.Metod"); // Создание экземпляра класса Metod

            if (o == null)
            {
                Console.WriteLine("Экземпляр не создан");
                return;
            }

            // Получаем тип класса Metod
            Type t = o.GetType();


            // Вычисляем значения в точках a, b, c
            // Задаем точки a, b и c
            double aValue = 0.5;
            double bValue = 1.0;
            double cValue = 1.5;

            MethodInfo mi = t.GetMethod("Calculate", new Type[] { typeof(double), typeof(double), typeof(double) }); // Указываем тип параметра
            if (mi == null)
            {
                Console.WriteLine("Вызывание метода не вышло");
                return;
            }

           
            Object[] parametersA = new Object[] { aValue };
            Object[] parametersB = new Object[] { bValue };
            Object[] parametersC = new Object[] { cValue };

            double resultA = (double)mi.Invoke(o, parametersA);
            double resultB = (double)mi.Invoke(o, parametersB);
            double resultC = (double)mi.Invoke(o, parametersC);

            // Определяем минимальное значение
            double minValueDin = Math.Min(resultA, Math.Min(resultB, resultC));
            string minPointDin = "";

            if (minValueDin == resultA)
                minPointDin = "a";
            else if (minValueDin == resultB)
                minPointDin = "b";
            else if (minValueDin == resultC)
                minPointDin = "c";

            // Выводим результаты
            Console.WriteLine($"Значение в точке a: {resultA}");
            Console.WriteLine($"Значение в точке b: {resultB}");
            Console.WriteLine($"Значение в точке c: {resultC}");
            Console.WriteLine($"Минимальное значение: {minValueDin} в точке {minPointDin}");



            //----------------------------------------------------------------------------------------------

            // Не динамическое подключение
            Metod mathFunctions = new Metod();

            // Задаем точки a, b, c
            double a = 0.5;
            double b = 1.0;
            double c = 1.5;

            // Вычисление в точках
            double valueA = mathFunctions.Calculate(a);
            double valueB = mathFunctions.Calculate(b);
            double valueC = mathFunctions.Calculate(c);
            //

            // Определение минимального значения
            double minValue = Math.Min(valueA, Math.Min(valueB, valueC));
            string minPoint = "";

            if (minValue == valueA)
                minPoint = "a";
            else if (minValue == valueB)
                minPoint = "b";
            else if (minValue == valueC)
                minPoint = "c";
            //

            // Вывод результататов
            Console.WriteLine($"Значение в точке a: {valueA}");
            Console.WriteLine($"Значение в точке b: {valueB}");
            Console.WriteLine($"Значение в точке c: {valueC}");
            Console.WriteLine($"Минимальное значение: {minValue} в точке {minPoint}");
            //

            Console.ReadLine();


        }
    }
}


