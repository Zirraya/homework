﻿using System;
using System.Reflection;
using Librarysincos;

namespace _4_6var_Nikitenko_211 // Задание 3 из 4 лабы
{
    internal class Program
    {
        static void Main(string[] args)
        {
                // Для получния данных о библиотеке, так чисто рудимент
                Assembly a = Assembly.LoadFrom("Librarysincos");
                Console.WriteLine(a.FullName); // получаем все типы из сборки 

                Type[] types = a.GetTypes();
                foreach (Type t in types)
                {
                    Console.WriteLine(t.Name);
                }
                //
           

            // Создаем экземпляр класса MathFunctions
        var metod = new Metod();

            // Вызываем метод для нахождения минимального значения
            var result = metod.FindMinValue();

            // Выводим результат
            Console.WriteLine($"Минимальное значение функции {result.minValue} достигается в точке {result.point}.");
        }
    }
}

